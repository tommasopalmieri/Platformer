//
//  sprite.hpp
//  SDLProject
//
//  Created by Sebastián Romero Cruz on 6/16/22.
//  Copyright © 2022 ctg. All rights reserved.
//

#ifndef sprite_hpp
#define sprite_hpp

//#include <stdio.h>
//#include <cstring>
//#include <SDL.h>
//#include <SDL_opengl.h>
//#include "glm/mat4x4.hpp"
//#include "glm/gtc/matrix_transform.hpp"
//#include "ShaderProgram.h"
//#include "stb_image.h"
//
//#define LOG(argument) std::cout << argument << '\n'
//
//const int NUMBER_OF_TEXTURES = 1; // to be generated, that is
//const GLint LEVEL_OF_DETAIL  = 0;  // base image level; Level n is the nth mipmap reduction image
//const GLint TEXTURE_BORDER   = 0;   // this value MUST be zero
//
//class Sprite
//{
//private:
//    glm::mat4 m_model_matrix = glm::mat4(1.0f);
//    GLuint m_texture_id {};
//    std::string m_sprite_filepath {};
//    
//public:
//    Sprite(std::string sprite_filepath);
//    void load_texture();
//    
//    const inline glm::mat4 get_model_matrix() const { return m_model_matrix; }
//    const inline GLuint get_texture_id()      const { return m_texture_id;   }
//};

#endif /* sprite_hpp */
